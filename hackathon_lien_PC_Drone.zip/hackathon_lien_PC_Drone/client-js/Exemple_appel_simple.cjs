// Exemple_appel_simple.cjs
const axios = require("axios");

const API_URL = "http://127.0.0.1:8080/plan-de-vol";

const planDeVol = [
  {
    function: "takeoff",
    sequence: 0,
    comment: "string",
    params: { alt_m: 0 }
  },
  {
    function: "go_to",
    sequence: 0,
    comment: "string",
    params: { lat_deg: 0, lon_deg: 0, alt_m: 0, radius_m: 0, wp_no: 0 }
  },
  {
    function: "climb_to",
    sequence: 0,
    comment: "string",
    params: { alt_m: 0, tol_m: 0, use_estimated_alt: true }
  },
  {
    function: "hold_here",
    sequence: 0,
    comment: "string",
    params: { hold_time_s: 0 }
  },
  {
    function: "return_to_home",
    sequence: 0,
    comment: "string"
  },
  {
    function: "land",
    sequence: 0,
    comment: "string"
  }
];

async function sendPlanDeVol() {
  try {
    const response = await axios.put(API_URL, planDeVol, {
      headers: { "Content-Type": "application/json", "accept": "application/json" }
    });
    console.log("Réponse :", response.data);
  } catch (error) {
    console.error("Erreur API :", error.response ? error.response.data : error.message);
  }
}

sendPlanDeVol();
