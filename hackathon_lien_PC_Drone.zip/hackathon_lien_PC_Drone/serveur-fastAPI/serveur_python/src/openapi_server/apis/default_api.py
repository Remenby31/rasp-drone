# coding: utf-8

from typing import Dict, List  # noqa: F401
import importlib
import pkgutil
import json
import time
import math

def haversine(lat1, lon1, lat2, lon2):
    R = 6371000  # rayon terrestre en mètres
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon/2)**2
    return 2 * R * math.asin(math.sqrt(a))

def has_reached_waypoint(drone, lat, lon, alt, pos_tol=2.0, alt_tol=1.0):
    if drone.gps.lat is None or drone.gps.lon is None:
        return False

    dist = haversine(drone.gps.lat, drone.gps.lon, lat, lon)
    alt_ok = abs((drone.altitude.estimated_alt or 0) - alt) <= alt_tol

    return dist <= pos_tol and alt_ok

def wait_until_reached(drone, func_name, params, timeout_s=60):
    start = time.time()

    while time.time() - start < timeout_s:
        if func_name == "takeoff":
            target = params.get("alt_m", 5)
            if abs(drone.altitude.estimated_alt - target) < 0.5:
                return True

        elif func_name == "go_to":
            if has_reached_waypoint(
                drone,
                params["lat_deg"],
                params["lon_deg"],
                params["alt_m"]
            ):
                return True

        elif func_name == "climb_to":
            target = params["alt_m"]
            if abs(drone.altitude.estimated_alt - target) < params.get("tol_m", 1.0):
                return True

        elif func_name == "hold_here":
            # hold_here se valide en temps uniquement
            return True

        elif func_name in ["return_to_home", "land"]:
            # On ne block pas sur RTH ou land (option possible si tu veux)
            return True

        time.sleep(0.2)

    return False


from serveur_python.src.openapi_server.apis.default_api_base import BaseDefaultApi
import serveur_python.src.openapi_server.impl

from fastapi import (  # noqa: F401
    APIRouter,
    Body,
    Cookie,
    Depends,
    Form,
    Header,
    HTTPException,
    Path,
    Query,
    Response,
    Security,
    status,
)

from serveur_python.src.openapi_server.models.extra_models import TokenModel  # noqa: F401
from typing import Any, List
from serveur_python.src.openapi_server.models.flight_action import FlightAction
from inav_drone import INavDrone  # importe ta classe INavDrone

router = APIRouter()

ns_pkg = serveur_python.src.openapi_server.impl
for _, name, _ in pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + "."):
    importlib.import_module(name)

drone = INavDrone(port="/dev/ttyUSB0", baudrate=115200)

@router.on_event("startup")
def startup_event():
    try:
        drone.connect()
    except Exception as e:
        print("Impossible de connecter le drone:", e)

@router.on_event("shutdown")
def shutdown_event():
    drone.disconnect()

@router.put(
    "/plan-de-vol",
    responses={
        200: {"description": "Plan de vol accepté"},
        400: {"description": "Requête invalide"},
        500: {"description": "Erreur interne"},
    },
    tags=["default"],
    summary="Exécute un plan de vol séquentiel",
)
async def plan_de_vol_put(
    flight_action: List[FlightAction] = Body(None, description="Liste d'actions de vol"),
) -> Dict[str, str]:
    if not flight_action:
        raise HTTPException(status_code=400, detail="Plan de vol vide")

    for action in flight_action:
        func = action.function.lower()
        params = action.params or {}

        try:

            # 1 — Exécution immédiate de l'action
            if func == "takeoff":
                drone.takeoff(target_alt=params.get("alt_m", 5))

            elif func == "go_to":
                drone.go_to(
                    lat_deg=params["lat_deg"],
                    lon_deg=params["lon_deg"],
                    alt_m=params["alt_m"],
                    radius_m=params.get("radius_m", 2.0),
                    wp_no=params.get("wp_no", 255),
                )

            elif func == "climb_to":
                drone.climb_to(
                    target_alt_m=params["alt_m"],
                    tol_m=params.get("tol_m", 1.0),
                    use_estimated_alt=params.get("use_estimated_alt", True),
                )

            elif func == "hold_here":
                drone.hold_here()
                time.sleep(params.get("hold_time_s", 1))

            elif func == "return_to_home":
                drone.return_to_home()

            elif func == "land":
                drone.land()

            else:
                raise HTTPException(status_code=400, detail=f"Fonction inconnue: {func}")

            # 2 — Attente (blocking) avant de passer à la séquence suivante
            if func not in ["return_to_home", "land"]:
                ok = wait_until_reached(drone, func, params)
                if not ok:
                    raise HTTPException(status_code=500, detail=f"L'action '{func}' n'a pas atteint son objectif dans le temps imparti")

        except KeyError as e:
            raise HTTPException(status_code=400, detail=f"Paramètre manquant pour {func}: {e}")

        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Erreur durant {func}: {e}")

    print(json.dumps([fa.to_dict() for fa in flight_action], indent=2))

    return Response(status_code=200)

