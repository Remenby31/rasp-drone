# coding: utf-8

from typing import ClassVar, Dict, List, Tuple  # noqa: F401

from typing import Any, List
from serveur_python.src.openapi_server.models.flight_action import FlightAction


class BaseDefaultApi:
    subclasses: ClassVar[Tuple] = ()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        BaseDefaultApi.subclasses = BaseDefaultApi.subclasses + (cls,)
    async def plan_de_vol_put(
        self,
        flight_action: List[FlightAction],
    ) -> None:
        """Reçoit une liste d’actions de vol. Chaque action doit correspondre à une fonction disponible (takeoff, go_to, climb_to, hold_here, return_to_home, land) et posséder uniquement les paramètres autorisés pour cette fonction. """
        ...
