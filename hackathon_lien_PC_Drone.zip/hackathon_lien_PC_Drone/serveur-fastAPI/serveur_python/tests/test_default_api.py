# coding: utf-8

from fastapi.testclient import TestClient


from typing import Any, List  # noqa: F401
from openapi_server.models.flight_action import FlightAction  # noqa: F401


def test_plan_de_vol_put(client: TestClient):
    """Test case for plan_de_vol_put

    Envoie un plan de vol au drone
    """
    flight_action = [{"sequence":0,"function":"takeoff","comment":"comment","params":"{}"}]

    headers = {
    }
    # uncomment below to make a request
    #response = client.request(
    #    "PUT",
    #    "/plan-de-vol",
    #    headers=headers,
    #    json=flight_action,
    #)

    # uncomment below to assert the status code of the HTTP response
    #assert response.status_code == 200

